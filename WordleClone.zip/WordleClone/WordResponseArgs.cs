﻿using System;

namespace WordleClone{
    public class WordResponseArgs : EventArgs
    {
    public Dictionary<string, dynamic> WordDetails { get; set; }

    }
}
