﻿using System;

namespace WordleClone
{
    public class SubmitButtonEventArgs : EventArgs
    {
        public string Word { get; set; }
    }

}

